var searchData=
[
  ['ef_5fgpio8_5ftype_0',['EF_GPIO8_TYPE',['../EF__GPIO8__regs_8h.html#a4e7962d913e6d2cfafb87592d2be93d0',1,'EF_GPIO8_regs.h']]]
];
