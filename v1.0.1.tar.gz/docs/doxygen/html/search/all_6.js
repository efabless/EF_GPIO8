var searchData=
[
  ['reserved_0',['reserved',['../struct__EF__GPIO8__TYPE__.html#af5af35481eb0f831ad543ea6394d44e2',1,'_EF_GPIO8_TYPE_']]],
  ['ris_1',['ris',['../struct__EF__GPIO8__TYPE__.html#ad1a09287fdef501a90c21cad11039f69',1,'_EF_GPIO8_TYPE_']]]
];
