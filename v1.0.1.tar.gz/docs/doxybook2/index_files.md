---
title: Files

---

# Files




* **file [EF_GPIO8.c](Files/EF__GPIO8_8c.md#file-ef-gpio8.c)** 
* **file [EF_GPIO8.h](Files/EF__GPIO8_8h.md#file-ef-gpio8.h)** <br>C header file for GPIO8 APIs which contains the function prototypes. 
* **file [EF_GPIO8_regs.h](Files/EF__GPIO8__regs_8h.md#file-ef-gpio8-regs.h)** 



-------------------------------

Updated on 2024-04-06 at 14:43:24 +0200
