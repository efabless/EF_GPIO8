---
title: _EF_GPIO8_TYPE_

---

# _EF_GPIO8_TYPE_






`#include <EF_GPIO8_regs.h>`

## Public Attributes

|                | Name           |
| -------------- | -------------- |
| [__R](Files/EF__GPIO8__regs_8h.md#define---r) | **[DATAI](Classes/struct__EF__GPIO8__TYPE__.md#variable-datai)**  |
| [__W](Files/EF__GPIO8__regs_8h.md#define---w) | **[DATAO](Classes/struct__EF__GPIO8__TYPE__.md#variable-datao)**  |
| [__W](Files/EF__GPIO8__regs_8h.md#define---w) | **[DIR](Classes/struct__EF__GPIO8__TYPE__.md#variable-dir)**  |
| [__R](Files/EF__GPIO8__regs_8h.md#define---r)[957] | **[reserved](Classes/struct__EF__GPIO8__TYPE__.md#variable-reserved)**  |
| [__RW](Files/EF__GPIO8__regs_8h.md#define---rw) | **[im](Classes/struct__EF__GPIO8__TYPE__.md#variable-im)**  |
| [__R](Files/EF__GPIO8__regs_8h.md#define---r) | **[mis](Classes/struct__EF__GPIO8__TYPE__.md#variable-mis)**  |
| [__R](Files/EF__GPIO8__regs_8h.md#define---r) | **[ris](Classes/struct__EF__GPIO8__TYPE__.md#variable-ris)**  |
| [__W](Files/EF__GPIO8__regs_8h.md#define---w) | **[icr](Classes/struct__EF__GPIO8__TYPE__.md#variable-icr)**  |

## Public Attributes Documentation

### variable DATAI

```cpp
__R DATAI;
```


### variable DATAO

```cpp
__W DATAO;
```


### variable DIR

```cpp
__W DIR;
```


### variable reserved

```cpp
__R[957] reserved;
```


### variable im

```cpp
__RW im;
```


### variable mis

```cpp
__R mis;
```


### variable ris

```cpp
__R ris;
```


### variable icr

```cpp
__W icr;
```


-------------------------------

Updated on 2024-04-06 at 14:43:24 +0200